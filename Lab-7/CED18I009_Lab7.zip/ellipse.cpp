#include <bits/stdc++.h>
#include <GL/freeglut.h>
#include <GL/gl.h>
#define PI 3.14159265359

void myInit()
{
	glClearColor(0.9, 1.0, 1.0, 1);
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-250, 250, -250, 250, -1, 1);
}

void MidpointEllipse(int cx, int cy, int rx, int ry, int rr, int rg, int rb)
{
	// decision parameter for region 1
	float d1 = (ry * ry) - (rx * rx * ry) + (0.25 * rx * rx);
	int x = 0;
	int y = ry;
	int dy = 2 * rx * rx * y;
	int dx = 2 * ry * ry * x;

	// region 1
	while (dx <= dy)
	{
		glBegin(GL_POINTS);
		glColor3ub(rr, rg, rb);
		glVertex2i(cx + x, cy + y);
		glVertex2i(cx - x, cy + y);
		glVertex2i(cx - x, cy - y);
		glVertex2i(cx + x, cy - y);
		glEnd();

		x = x + 1;
		if (d1 < 0)
		{
			dx = dx + (2 * ry * ry);
			d1 = d1 + dx + (ry * ry);
			y = y;
		}
		else
		{
			dx = dx + (2 * ry * ry);
			dy = dy - (2 * rx * rx);
			d1 = d1 + dx - dy + (ry * ry);
			y = y - 1;
		}
	}

	// decision parameter for region 2
	float d2 = ((ry * ry) * ((x + 0.5) * (x + 0.5))) + ((rx * rx) * ((y - 1) * (y - 1))) - (rx * rx * ry * ry);

	//region 2
	while (y >= 0)
	{
		glBegin(GL_POINTS);
		glColor3ub(rr, rg, rb);
		glVertex2i(cx + x, cy + y);
		glVertex2i(cx - x, cy + y);
		glVertex2i(cx - x, cy - y);
		glVertex2i(cx + x, cy - y);
		glEnd();

		y = y - 1;
		if (d2 > 0)
		{
			dy = dy - (2 * rx * rx);
			d2 = d2 + (rx * rx) - dy;
		}
		else
		{
			x = x + 1;
			dx = dx + (2 * ry * ry);
			dy = dy - (2 * rx * rx);
			d2 = d2 + dx - dy + (rx * rx);
		}
	}
}

void ParametricEllipse(int cx, int cy, int rx, int ry, int rr, int rg, int rb)
{
	GLfloat theta11;
	glBegin(GL_POINTS);
	glColor3ub(rr, rg, rb);
	for (int i = 0; i <= 360; i++)
	{
		theta11 = i * PI / 180;
		glVertex2f(cx + rx * cos(theta11), cy + ry * sin(theta11));
	}
	glEnd();
}

void GeneralEllipse(int cx, int cy, int rx, int ry, int rr, int rg, int rb)
{
	int x = 0;
	int y = ry;
	int dy = 2 * rx * rx * y;
	int dx = 2 * ry * ry * x;

	while (y >= 0)
	{
		glBegin(GL_POINTS);
		glColor3ub(rr, rg, rb);
		glVertex2i(cx + x, cy + y);
		glVertex2i(cx - x, cy + y);
		glVertex2i(cx - x, cy - y);
		glVertex2i(cx + x, cy - y);
		glEnd();

		if (dx < dy)
		{
			x = x + 1;
			y = round(sqrt(((rx * rx * ry * ry) - (ry * ry * (x) * (x))) / (rx * rx)));
		}
		else
		{
			y = y - 1;
			x = round(sqrt(((rx * rx * ry * ry) - (rx * rx * (y) * (y))) / (ry * ry)));
		}
		dy = 2 * rx * rx * y;
		dx = 2 * ry * ry * x;
	}
}

void drawEllipse()
{
	glPointSize(3);
	srand(time(0));
	int rr = rand() % 256;
	int rg = rand() % 256;
	int rb = rand() % 256;

	int startAngle = (rand() % 721) - 360;
	int endAngle = (rand() % 721) - 360;
	int rx = (rand() % 51) + 50;
	int ry = (rand() % 51) + 50;
	int cx = (rand() % 101) - 50;
	int cy = (rand() % 101) - 50;

	// midpoint
	MidpointEllipse(cx, cy, rx, ry, rr, rg, rb);

	// using parametric form
	ParametricEllipse(cx, cy, rx, ry, rr, rg, rb);

	// using general equation
	GeneralEllipse(cx, cy, rx, ry, rr, rg, rb);

	glFlush();
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition((glutGet(GLUT_SCREEN_WIDTH) - 1200) / 2, (glutGet(GLUT_SCREEN_HEIGHT) - 740) / 2);
	glutInitWindowSize(1200, 740);
	glutCreateWindow("Ellipse");
	glutDisplayFunc(drawEllipse);
	myInit();
	glutMainLoop();
	return 0;
}