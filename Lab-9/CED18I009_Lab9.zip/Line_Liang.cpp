#include <bits/stdc++.h>
#include <GL/freeglut.h>
#include <GL/glut.h>
using namespace std;
const int SIZE = 1000;

void myInit()
{
	glClearColor(0.9, 0.9, 0.9, 0);
	glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0, 1000, 0, 1000);
}

void swap(int &x1, int &y1, int &x2, int &y2)
{
	int temp1, temp2;
	temp1 = x1;
	temp2 = y1;
	x1 = x2;
	y1 = y2;
	x2 = temp1;
	y2 = temp2;
}

double spoint(double p1, double p2, double p3, double p4, double q1, double q2, double q3, double q4)
{
	double res = 0;
	if (p1 < 0)
		res = (q1 / p1 > res) ? q1 / p1 : res;
	if (p2 < 0)
		res = (q2 / p2 > res) ? q2 / p2 : res;
	if (p3 < 0)
		res = (q3 / p3 > res) ? q3 / p3 : res;
	if (p4 < 0)
		res = (q4 / p4 > res) ? q4 / p4 : res;
	return res;
}

double epoint(double p1, double p2, double p3, double p4, double q1, double q2, double q3, double q4)
{
	double res = 1;
	if (p1 > 0)
		res = ((q1 / p1) < res) ? q1 / p1 : res;
	if (p2 > 0)
		res = ((q2 / p2) < res) ? q2 / p2 : res;
	if (p3 > 0)
		res = ((q3 / p3) < res) ? q3 / p3 : res;
	if (p4 > 0)
		res = ((q4 / p4) < res) ? q4 / p4 : res;
	return res;
}

void BSL_drawLine(int x1, int y1, int x2, int y2, vector<float> color = {1.0, 0.0, 0.0}, int pointSize = 2)
{
	//points (x1,y1) and (x2,y2)
	glPointSize(pointSize);
	glColor3f(color[0], color[1], color[2]);

	glBegin(GL_POINTS);
	double slope = ((double)y2 - (double)y1) / ((double)x2 - (double)x1);

	if (slope >= -1 && slope <= 1)
	{ // 1st,4th,5th and 8th octants

		if (x2 < x1)
		{ //(x1,y1) is made to have lesser abscissa
			swap(x1, y1, x2, y2);
		}

		if (y1 <= y2)
		{ //1st and 5th octant

			int delx = x2 - x1, dely = y2 - y1;
			int two_delx = 2 * delx, two_dely = 2 * dely;
			int diff = two_dely - two_delx;

			int p = two_dely - delx;
			int x, y = y1;
			for (x = x1; x <= x2; x++)
			{
				glVertex2i(x, y);

				if (p < 0)
				{
					y = y;
					p = p + two_dely;
				}
				else
				{
					y = y + 1;
					p = p + diff;
				}
			}
		}
		else
		{ //8th and 4th octant

			int delx = x2 - x1, dely = y2 - y1;
			int two_delx = 2 * delx, two_dely = 2 * dely;
			int diff = -two_dely - two_delx;

			int p = -two_dely - delx;
			int x, y = y1;
			for (x = x1; x <= x2; x++)
			{

				glVertex2i(x, y);

				if (p < 0)
				{
					y = y;
					p = p - two_dely;
				}
				else
				{
					y = y - 1;
					p = p + diff;
				}
			}
		}
	}
	else
	{
		if (y2 < y1)
		{ //(x1,y1) is made to have lesser ordinate
			swap(x1, y1, x2, y2);
		}

		if (slope > 1)
		{ //2nd and 6th octant  //mirror to 1st octant: (x,y) ==> (y,x)

			int delx = y2 - y1, dely = x2 - x1;
			int two_delx = 2 * delx, two_dely = 2 * dely;
			int diff = two_dely - two_delx;

			int p = two_dely - delx;
			int x, y = x1;
			for (x = y1; x <= y2; x++)
			{
				glVertex2i(y, x); //inverse plotting

				if (p < 0)
				{
					y = y;
					p = p + two_dely;
				}
				else
				{
					y = y + 1;
					p = p + diff;
				}
			}
		}
		else
		{ //3rd and 7th octant   //mirror to 8th octant :(x,y) ==> (-y, -x)

			int delx = -y1 + y2, dely = -x1 + x2;
			int two_delx = 2 * delx, two_dely = 2 * dely;
			int diff = -two_dely - two_delx;

			int p = -two_dely - delx;
			int x, y = -x2;
			for (x = -y2; x <= -y1; x++)
			{

				glVertex2i(-y, -x); //inverse plotting

				if (p < 0)
				{
					y = y;
					p = p - two_dely;
				}
				else
				{
					y = y - 1;
					p = p + diff;
				}
			}
		}
	}
	glEnd();
}
void draw()
{
	srand(time(0));
	int n = rand() % (25);
	int a_count = 0, r_count = 0;
	vector<vector<int>> lines;
	vector<vector<float>> color;
	for (int i = 0; i < n; i++)
	{
		lines.push_back({rand() % SIZE, rand() % SIZE, rand() % SIZE, rand() % SIZE}); //x1,y1,x2,y2
		color.push_back({0, 1, 0});
	}

	int x_min = rand() % SIZE, x_max = x_min + rand() % (SIZE - x_min);
	int y_min = rand() % SIZE, y_max = y_min + rand() % (SIZE - y_min);

	//Window
	BSL_drawLine(x_min, y_min, x_min, y_max, {0, 0, 1});
	BSL_drawLine(x_min, y_max, x_max, y_max, {0, 0, 1});
	BSL_drawLine(x_max, y_max, x_max, y_min, {0, 0, 1});
	BSL_drawLine(x_max, y_min, x_min, y_min, {0, 0, 1});

	glPointSize(1);

	glBegin(GL_POINTS);
	for (int i = 0; i < n; i++)
	{
		double x1 = lines[i][0], y1 = lines[i][1], x2 = lines[i][2], y2 = lines[i][3];
		int delx = x2 - x1, dely = y2 - y1;
		double p1 = -delx, p2 = delx, p3 = -dely, p4 = dely;
		double q1 = x1 - x_min, q2 = x_max - x1, q3 = y1 - y_min, q4 = y_max - y1;
		double u1, u2;

		BSL_drawLine(x1, y1, x2, y2, {1, 0, 0});

		if ((p1 == 0 || p2 == 0) && (q1 < 0 || q2 < 0))
			r_count++;
		else if ((p3 == 0 || p4 == 0) && (q3 < 0 || q2 < 0))
			r_count++;
		else
		{
			u1 = spoint(p1, p2, p3, p4, q1, q2, q3, q4);
			u2 = epoint(p1, p2, p3, p4, q1, q2, q3, q4);

			if (u1 <= u2)
			{
				x2 = x1 + u2 * delx;
				y2 = y1 + u2 * dely;
				x1 = x1 + u1 * delx;
				y1 = y1 + u1 * dely;
				BSL_drawLine(x1, y1, x2, y2, color[i]);
				a_count++;
			}
			else
				r_count++;
		}
	}
	glEnd();

	glFlush();
}

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition((glutGet(GLUT_SCREEN_WIDTH) - 1200) / 2, (glutGet(GLUT_SCREEN_HEIGHT) - 740) / 2);
	glutInitWindowSize(1200, 740);
	glutCreateWindow("Line Clipping Liang_Barsky");
	glutDisplayFunc(draw);
	myInit();
	glutMainLoop();
	return 0;
}
